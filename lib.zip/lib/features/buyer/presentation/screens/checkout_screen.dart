import 'package:ecom/core/providers/common_providers.dart';
import 'package:ecom/core/widgets/app_empty_view.dart';
import 'package:ecom/core/widgets/app_price_text.dart';
import 'package:ecom/core/widgets/responsive_layout.dart';
import 'package:ecom/features/auth/domain/entities/user_address.dart';
import 'package:ecom/features/auth/presentation/controllers/address_controller.dart';
import 'package:ecom/features/buyer/domain/entities/cart_item.dart';
import 'package:ecom/features/buyer/presentation/controllers/cart_controller.dart';
import 'package:ecom/features/orders/domain/entities/order.dart';
import 'package:ecom/features/orders/domain/entities/order_item.dart';
import 'package:ecom/features/orders/domain/entities/order_status.dart';
import 'package:ecom/features/orders/presentation/controllers/order_controller.dart';
import 'package:ecom/shared/presentation/navigation/router.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

class CheckoutScreen extends ConsumerStatefulWidget {
  const CheckoutScreen({super.key});

  @override
  ConsumerState<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends ConsumerState<CheckoutScreen> {
  UserAddress? _selectedAddress;
  bool _isProcessing = false;
  String _paymentMethod = 'COD';

  @override
  Widget build(BuildContext context) {
    final cartItems = ref.watch(cartControllerProvider);
    final addressesAsync = ref.watch(userAddressesProvider);
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    addressesAsync.whenData((addresses) {
      if (_selectedAddress == null && addresses.isNotEmpty) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) {
            setState(() {
              _selectedAddress = addresses.firstWhere(
                (a) => a.isDefault,
                orElse: () => addresses.first,
              );
            });
          }
        });
      }
    });

    if (cartItems.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('Checkout')),
        body: AppEmptyView(
          title: 'Cart is empty',
          subtitle: 'Add items to your cart before checking out.',
          icon: Icons.shopping_cart_outlined,
          action: FilledButton(
            onPressed: () => context.go('/buyer/home'),
            child: const Text('Go Shopping'),
          ),
        ),
      );
    }

    final groupedItems = <String, List<CartItem>>{};
    for (final item in cartItems) {
      groupedItems.putIfAbsent(item.storeId, () => <CartItem>[]);
      groupedItems[item.storeId]!.add(item);
    }

    final subtotal = cartItems.fold<double>(
      0,
      (sum, item) => sum + (item.unitPrice * item.quantity),
    );
    final platformFee = subtotal * 0.02;
    double deliveryFee = 0;
    groupedItems.forEach((storeId, items) {
      final storeSubtotal = items.fold<double>(
        0,
        (sum, item) => sum + (item.unitPrice * item.quantity),
      );
      if (storeSubtotal < 1000) {
        deliveryFee += 99.0;
      }
    });

    final total = subtotal + platformFee + deliveryFee;

    return Scaffold(
      backgroundColor: colorScheme.surface,
      appBar: AppBar(title: const Text('Checkout'), centerTitle: true),
      body: _isProcessing
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const CircularProgressIndicator(),
                  const SizedBox(height: 16),
                  Text(
                    'Placing your order...',
                    style: theme.textTheme.bodyLarge,
                  ),
                ],
              ),
            )
          : ResponsiveLayout(
              maxWidth: 800,
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildAddressSection(addressesAsync, colorScheme, theme),
                    const SizedBox(height: 32),
                    _buildOrderSummary(groupedItems, theme, colorScheme),
                    const SizedBox(height: 32),
                    _buildPaymentMethodSection(colorScheme, theme),
                    const SizedBox(height: 32),
                    _buildBillCard(
                      subtotal,
                      platformFee,
                      deliveryFee,
                      total,
                      theme,
                      colorScheme,
                    ),
                    const SizedBox(height: 120),
                  ],
                ),
              ),
            ),
      bottomSheet: _isProcessing
          ? null
          : _buildBottomBar(total, cartItems, colorScheme, theme),
    );
  }

  Widget _buildAddressSection(
    AsyncValue<List<UserAddress>> addressesAsync,
    ColorScheme colorScheme,
    ThemeData theme,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Delivery Address',
              style: theme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            TextButton(
              onPressed: () => context.push(AppRoutes.buyerAddresses),
              child: const Text('Manage'),
            ),
          ],
        ),
        const SizedBox(height: 12),
        addressesAsync.when(
          loading: () => const LinearProgressIndicator(),
          error: (e, _) => Text('Error loading addresses: $e'),
          data: (addresses) {
            if (addresses.isEmpty) {
              return _buildAddressPlaceholder(colorScheme, theme);
            }
            if (_selectedAddress == null) {
              return _buildAddressPlaceholder(colorScheme, theme);
            }
            return _buildAddressCard(colorScheme, theme);
          },
        ),
      ],
    );
  }

  Widget _buildAddressPlaceholder(ColorScheme colorScheme, ThemeData theme) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: colorScheme.errorContainer.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: colorScheme.error.withValues(alpha: 0.3)),
      ),
      child: Column(
        children: [
          Icon(Icons.location_off_outlined, color: colorScheme.error, size: 32),
          const SizedBox(height: 8),
          const Text(
            'No address selected',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          TextButton(
            onPressed: () => context.push(AppRoutes.buyerAddresses),
            child: const Text('Add Shipping Address'),
          ),
        ],
      ),
    );
  }

  Widget _buildAddressCard(ColorScheme colorScheme, ThemeData theme) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: colorScheme.primary, width: 1.5),
      ),
      child: Row(
        children: [
          Icon(Icons.location_on_outlined, color: colorScheme.primary),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _selectedAddress?.fullName ?? '',
                  style: theme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  _selectedAddress?.fullAddress ?? '',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: colorScheme.onSurfaceVariant,
                  ),
                ),
                Text(
                  'Phone: ${_selectedAddress?.phone ?? ''}',
                  style: theme.textTheme.bodySmall,
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.keyboard_arrow_down),
            onPressed: _showAddressPicker,
          ),
        ],
      ),
    );
  }

  void _showAddressPicker() {
    final addresses = ref.read(userAddressesProvider).value ?? [];
    if (addresses.isEmpty) {
      context.push(AppRoutes.buyerAddresses);
      return;
    }

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) => Container(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Select Delivery Address',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            ...addresses.map(
              (a) => ListTile(
                title: Text(a.fullName),
                subtitle: Text(a.fullAddress),
                trailing: a.id == _selectedAddress?.id
                    ? const Icon(Icons.check_circle, color: Colors.green)
                    : null,
                onTap: () {
                  setState(() => _selectedAddress = a);
                  Navigator.pop(context);
                },
              ),
            ),
            const SizedBox(height: 8),
            TextButton.icon(
              onPressed: () {
                Navigator.pop(context);
                context.push(AppRoutes.buyerAddresses);
              },
              icon: const Icon(Icons.add),
              label: const Text('Add New Address'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOrderSummary(
    Map<String, List<CartItem>> groupedItems,
    ThemeData theme,
    ColorScheme colorScheme,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Order Summary',
          style: theme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        ...groupedItems.entries.map((entry) {
          final storeName = entry.value.first.storeName;
          return Container(
            margin: const EdgeInsets.only(bottom: 16),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              border: Border.all(
                color: colorScheme.outlineVariant.withValues(alpha: 0.5),
              ),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.storefront,
                      size: 16,
                      color: colorScheme.primary,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      storeName,
                      style: theme.textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: colorScheme.primary,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                ...entry.value.map(
                  (item) => _buildOrderItem(item, theme, colorScheme),
                ),
              ],
            ),
          );
        }),
      ],
    );
  }

  Widget _buildOrderItem(
    CartItem item,
    ThemeData theme,
    ColorScheme colorScheme,
  ) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Image.network(
              item.imageUrl,
              width: 50,
              height: 50,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) => Container(
                width: 50,
                height: 50,
                color: colorScheme.surfaceContainerHighest,
                child: const Icon(Icons.image_outlined, size: 24),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.title,
                  style: theme.textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                Text('Qty: ${item.quantity}', style: theme.textTheme.bodySmall),
              ],
            ),
          ),
          AppPriceText(amount: item.unitPrice * item.quantity),
        ],
      ),
    );
  }

  Widget _buildPaymentMethodSection(ColorScheme colorScheme, ThemeData theme) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Payment Method',
          style: theme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        RadioGroup<String>(
          groupValue: _paymentMethod,
          onChanged: (val) => setState(() => _paymentMethod = val!),
          child: Column(
            children: [
              _PaymentOptionTile(
                icon: Icons.money,
                title: 'Cash on Delivery',
                subtitle: 'Pay when your order arrives',
                value: 'COD',
                isSelected: _paymentMethod == 'COD',
              ),
              _PaymentOptionTile(
                icon: Icons.account_balance_wallet_outlined,
                title: 'UPI Payment',
                subtitle: 'Pay via UPI apps',
                value: 'UPI',
                isSelected: _paymentMethod == 'UPI',
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildBillCard(
    double subtotal,
    double platformFee,
    double deliveryFee,
    double total,
    ThemeData theme,
    ColorScheme colorScheme,
  ) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: colorScheme.surfaceContainerHighest.withValues(alpha: 0.2),
        borderRadius: BorderRadius.circular(24),
      ),
      child: Column(
        children: [
          _billRow('Subtotal', subtotal, theme),
          const SizedBox(height: 12),
          _billRow('Platform Fee (2%)', platformFee, theme),
          const SizedBox(height: 12),
          _billRow(
            deliveryFee == 0 ? 'Delivery (Free)' : 'Delivery Fee',
            deliveryFee,
            theme,
          ),
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 16),
            child: Divider(),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Total Payable',
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                '₹${total.toStringAsFixed(2)}',
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: colorScheme.primary,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildBottomBar(
    double total,
    List<CartItem> cartItems,
    ColorScheme colorScheme,
    ThemeData theme,
  ) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        border: Border(
          top: BorderSide(
            color: colorScheme.outlineVariant.withValues(alpha: 0.5),
          ),
        ),
      ),
      child: SafeArea(
        child: SizedBox(
          width: double.infinity,
          height: 60,
          child: FilledButton(
            onPressed: _selectedAddress == null
                ? null
                : () => _handlePlaceOrder(cartItems),
            style: FilledButton.styleFrom(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18),
              ),
            ),
            child: Text(
              _selectedAddress == null
                  ? 'Select Address to Continue'
                  : 'Confirm Order — ₹${total.toStringAsFixed(2)}',
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _handlePlaceOrder(List<CartItem> cartItems) async {
    final userId = ref.read(currentUserIdProvider);
    if (userId == null || _selectedAddress == null) return;

    setState(() => _isProcessing = true);

    try {
      final groupedBySeller = <String, List<CartItem>>{};
      for (final item in cartItems) {
        groupedBySeller.putIfAbsent(item.storeId, () => []);
        groupedBySeller[item.storeId]!.add(item);
      }

      final ordersToCreate = <AppOrder>[];
      final now = DateTime.now();

      for (final entry in groupedBySeller.entries) {
        final items = entry.value;
        final sub = items.fold<double>(
          0,
          (sum, item) => sum + (item.unitPrice * item.quantity),
        );
        final delFee = sub < 1000 ? 99.0 : 0.0;
        final platFee = sub * 0.02;

        ordersToCreate.add(
          AppOrder(
            orderId: '',
            buyerId: userId,
            buyerName: _selectedAddress!.fullName,
            storeId: entry.key,
            storeName: items.first.storeName,
            status: OrderStatus.pending,
            items: items
                .map(
                  (i) => OrderItem(
                    productId: i.productId,
                    title: i.title,
                    imageUrl: i.imageUrl,
                    quantity: i.quantity,
                    unitPrice: i.unitPrice,
                  ),
                )
                .toList(),
            subtotal: sub,
            deliveryFee: delFee,
            platformFee: platFee,
            totalAmount: sub + delFee + platFee,
            paymentMethod: _paymentMethod,
            paymentStatus: 'pending',
            deliveryAddress: _selectedAddress!.fullAddress,
            createdAt: now,
            updatedAt: now,
          ),
        );
      }

      await ref
          .read(orderControllerProvider.notifier)
          .checkout(
            orders: ordersToCreate,
            onFailure: (error) {
              if (!mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Order failed: $error'),
                  backgroundColor: Colors.red,
                ),
              );
              setState(() => _isProcessing = false);
            },
            onSuccess: () async {
              await ref.read(cartControllerProvider.notifier).clearCart();
              if (!mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Order placed successfully!'),
                  backgroundColor: Colors.green,
                ),
              );
              context.go('/buyer/orders');
            },
          );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error: $e')));
      setState(() => _isProcessing = false);
    }
  }

  Widget _billRow(String label, double amount, ThemeData theme) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: theme.textTheme.bodyLarge),
        Text(
          '₹${amount.toStringAsFixed(2)}',
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ],
    );
  }
}

class _PaymentOptionTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final String value;
  final bool isSelected;

  const _PaymentOptionTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.value,
    required this.isSelected,
  });

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isSelected ? colorScheme.primary : colorScheme.outlineVariant,
          width: isSelected ? 2 : 1,
        ),
      ),
      child: RadioListTile<String>(
        value: value,
        title: Row(
          children: [
            Icon(icon, size: 20, color: colorScheme.primary),
            const SizedBox(width: 8),
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
        subtitle: Text(subtitle),
        activeColor: colorScheme.primary,
      ),
    );
  }
}
