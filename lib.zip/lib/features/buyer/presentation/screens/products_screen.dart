import 'dart:ui';

import 'package:ecom/core/providers/categories_provider.dart';
import 'package:ecom/core/theme/app_colors.dart';
import 'package:ecom/core/widgets/app_error_view.dart';
import 'package:ecom/core/widgets/app_loading_view.dart';
import 'package:ecom/features/buyer/presentation/widgets/buyer_anti_gravity_widgets.dart';
import 'package:ecom/features/buyer/presentation/widgets/buyer_side_drawer.dart';
import 'package:ecom/features/marketplace/domain/entities/catalog_item.dart';
import 'package:ecom/features/marketplace/presentation/controllers/marketplace_controller.dart';
import 'package:ecom/shared/presentation/widgets/cart_icon_with_badge.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';

// ─────────────────────────────────────────────────────────────────────────────
// ENTRY — loads categories then hands off to stateful content
// ─────────────────────────────────────────────────────────────────────────────

class ProductsScreen extends ConsumerWidget {
  const ProductsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final categoriesAsync = ref.watch(activeCategoriesStreamProvider);

    return categoriesAsync.when(
      loading: () => const Scaffold(body: AppLoadingView()),
      error: (e, _) => Scaffold(body: AppErrorView(message: e.toString())),
      data: (categories) {
        final filterCategories = List<String>.from(categories);
        if (!filterCategories.contains('All')) {
          filterCategories.insert(0, 'All');
        }
        return ProductsScreenContent(categories: filterCategories);
      },
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// CONTENT
// ─────────────────────────────────────────────────────────────────────────────

class ProductsScreenContent extends ConsumerStatefulWidget {
  final List<String> categories;

  const ProductsScreenContent({super.key, required this.categories});

  @override
  ConsumerState<ProductsScreenContent> createState() =>
      _ProductsScreenContentState();
}

class _ProductsScreenContentState extends ConsumerState<ProductsScreenContent>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final FocusNode _searchFocus = FocusNode();

  bool _isSearching = false;
  String _searchQuery = '';
  String _sortMode =
      'popular'; // 'popular' | 'price_asc' | 'price_desc' | 'newest'

  @override
  void initState() {
    super.initState();
    _tabController = TabController(
      length: widget.categories.length,
      vsync: this,
    );
    _tabController.addListener(() {
      if (!_tabController.indexIsChanging) setState(() {});
    });
    _searchController.addListener(() {
      setState(() => _searchQuery = _searchController.text.trim());
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    _scrollController.dispose();
    _searchFocus.dispose();
    super.dispose();
  }

  // ── Helpers ────────────────────────────────────────────────────────────────

  List<CatalogItem> _applyFilters(List<CatalogItem> all) {
    final category = widget.categories[_tabController.index];
    var list = all.where((p) {
      final matchQ =
          _searchQuery.isEmpty ||
          p.title.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          p.description.toLowerCase().contains(_searchQuery.toLowerCase());
      final matchC =
          category == 'All' ||
          (p.metadata['category'] as String?)?.toLowerCase() ==
              category.toLowerCase();
      return matchQ && matchC;
    }).toList();

    switch (_sortMode) {
      case 'price_asc':
        list.sort((a, b) => a.basePrice.compareTo(b.basePrice));
      case 'price_desc':
        list.sort((a, b) => b.basePrice.compareTo(a.basePrice));
      case 'newest':
        list = list.reversed.toList();
      default:
        break;
    }
    return list;
  }

  void _showSortSheet() {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => _SortSheet(
        isDark: isDark,
        current: _sortMode,
        onSelected: (v) {
          setState(() => _sortMode = v);
          Navigator.pop(context);
        },
      ),
    );
  }

  // ── Build ──────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final productsAsync = ref.watch(marketplaceControllerProvider);

    return Scaffold(
      backgroundColor: isDark
          ? AppColors.darkBgPrimary
          : AppColors.lightBgPrimary,
      drawer: const BuyerSideDrawer(),
      body: Stack(
        children: [
          // ── Atmospheric background ──────────────────────────────────────
          const IgnorePointer(child: OrbBackgroundWidget()),

          // ── Main content ───────────────────────────────────────────────
          CustomScrollView(
            controller: _scrollController,
            physics: const BouncingScrollPhysics(),
            slivers: [
              _buildSliverAppBar(isDark),
              _buildCategoryBar(isDark),
              _buildActiveFiltersBar(isDark),
              productsAsync.when(
                data: (products) => _buildProductGrid(products, isDark),
                loading: () => const SliverFillRemaining(
                  child: Center(child: CircularProgressIndicator()),
                ),
                error: (e, _) => SliverFillRemaining(
                  child: Center(child: Text('Error: $e')),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ── Sliver AppBar ──────────────────────────────────────────────────────────

  Widget _buildSliverAppBar(bool isDark) {
    return SliverAppBar(
      expandedHeight: 120,
      floating: true,
      pinned: true,
      snap: true,
      backgroundColor: Colors.transparent,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      flexibleSpace: ClipRect(
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
          child: FlexibleSpaceBar(
            background: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: isDark
                      ? [
                          AppColors.darkBgPrimary.withValues(alpha: 0.95),
                          AppColors.darkBgPrimary.withValues(alpha: 0.7),
                        ]
                      : [
                          AppColors.lightBgPrimary.withValues(alpha: 0.95),
                          AppColors.lightBgPrimary.withValues(alpha: 0.7),
                        ],
                ),
              ),
              child: SafeArea(
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 12,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Row(
                        children: [
                          Builder(
                            builder: (ctx) => GestureDetector(
                              onTap: () => Scaffold.of(ctx).openDrawer(),
                              child: _GlassIcon(
                                isDark: isDark,
                                icon: Icons.menu_rounded,
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _isSearching
                                ? _buildSearchField(isDark)
                                : Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'Discover',
                                        style: GoogleFonts.playfairDisplay(
                                          fontSize: 28,
                                          fontWeight: FontWeight.w700,
                                          color: isDark
                                              ? AppColors.darkTextPrimary
                                              : AppColors.lightTextPrimary,
                                          height: 1,
                                        ),
                                      ),
                                      Text(
                                        'Find what you love',
                                        style: GoogleFonts.inter(
                                          fontSize: 12,
                                          color: isDark
                                              ? AppColors.darkTextSecond
                                              : AppColors.lightTextSecond,
                                          fontWeight: FontWeight.w400,
                                        ),
                                      ),
                                    ],
                                  ),
                          ),
                          if (!_isSearching) ...[
                            _GlassIcon(
                              isDark: isDark,
                              icon: Icons.search_rounded,
                              onTap: () => setState(() => _isSearching = true),
                            ),
                            const SizedBox(width: 8),
                            const CartIconWithBadge(),
                            const SizedBox(width: 8),
                            _GlassIcon(
                              isDark: isDark,
                              icon: Icons.tune_rounded,
                              onTap: _showSortSheet,
                            ),
                          ] else
                            _GlassIcon(
                              isDark: isDark,
                              icon: Icons.close_rounded,
                              onTap: () => setState(() {
                                _isSearching = false;
                                _searchController.clear();
                                _searchQuery = '';
                              }),
                            ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSearchField(bool isDark) {
    return Container(
      height: 40,
      decoration: BoxDecoration(
        color: isDark
            ? Colors.white.withValues(alpha: 0.08)
            : Colors.black.withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.primary.withValues(alpha: 0.3)),
      ),
      child: TextField(
        controller: _searchController,
        focusNode: _searchFocus,
        autofocus: true,
        style: GoogleFonts.inter(
          color: isDark
              ? AppColors.darkTextPrimary
              : AppColors.lightTextPrimary,
          fontSize: 14,
          fontWeight: FontWeight.w500,
        ),
        decoration: InputDecoration(
          hintText: 'Search products...',
          hintStyle: GoogleFonts.inter(
            color: isDark
                ? AppColors.darkTextSecond
                : AppColors.lightTextSecond,
            fontSize: 14,
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 14,
            vertical: 10,
          ),
          prefixIcon: Icon(
            Icons.search_rounded,
            size: 18,
            color: isDark
                ? AppColors.darkTextSecond
                : AppColors.lightTextSecond,
          ),
        ),
      ),
    );
  }

  // ── Category Tab Bar ───────────────────────────────────────────────────────

  Widget _buildCategoryBar(bool isDark) {
    return SliverPersistentHeader(
      pinned: true,
      delegate: _CategoryBarDelegate(
        isDark: isDark,
        tabController: _tabController,
        categories: widget.categories,
      ),
    );
  }

  // ── Active Filters Bar ─────────────────────────────────────────────────────

  Widget _buildActiveFiltersBar(bool isDark) {
    final hasFilters = _searchQuery.isNotEmpty || _sortMode != 'popular';
    if (!hasFilters) return const SliverToBoxAdapter(child: SizedBox.shrink());

    return SliverToBoxAdapter(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
        child: Wrap(
          spacing: 8,
          children: [
            if (_searchQuery.isNotEmpty)
              _FilterChip(
                label: '"$_searchQuery"',
                isDark: isDark,
                onRemove: () => setState(() {
                  _searchController.clear();
                  _searchQuery = '';
                }),
              ),
            if (_sortMode != 'popular')
              _FilterChip(
                label: _sortLabel(_sortMode),
                isDark: isDark,
                onRemove: () => setState(() => _sortMode = 'popular'),
              ),
          ],
        ),
      ),
    );
  }

  String _sortLabel(String mode) => switch (mode) {
    'price_asc' => 'Price: Low → High',
    'price_desc' => 'Price: High → Low',
    'newest' => 'Newest',
    _ => 'Popular',
  };

  // ── Product Grid ───────────────────────────────────────────────────────────

  Widget _buildProductGrid(List<CatalogItem> all, bool isDark) {
    final filtered = _applyFilters(all);

    if (filtered.isEmpty) {
      return SliverFillRemaining(child: _EmptyState(isDark: isDark));
    }

    return SliverPadding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
      sliver: SliverLayoutBuilder(
        builder: (context, constraints) {
          final crossAxisCount = constraints.crossAxisExtent >= 900
              ? 4
              : constraints.crossAxisExtent >= 600
              ? 3
              : 2;
          return SliverGrid(
            delegate: SliverChildBuilderDelegate(
              (ctx, i) => _ProductCard(
                item: filtered[i],
                isDark: isDark,
                onTap: () =>
                    context.push('/buyer/home/product/${filtered[i].id}'),
              ),
              childCount: filtered.length,
            ),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: crossAxisCount,
              crossAxisSpacing: 14,
              mainAxisSpacing: 14,
              childAspectRatio: 0.68,
            ),
          );
        },
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// CATEGORY BAR DELEGATE
// ─────────────────────────────────────────────────────────────────────────────

class _CategoryBarDelegate extends SliverPersistentHeaderDelegate {
  final bool isDark;
  final TabController tabController;
  final List<String> categories;

  _CategoryBarDelegate({
    required this.isDark,
    required this.tabController,
    required this.categories,
  });

  @override
  double get minExtent => 56;

  @override
  double get maxExtent => 56;

  @override
  Widget build(
    BuildContext context,
    double shrinkOffset,
    bool overlapsContent,
  ) {
    return ClipRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
        child: Container(
          color: isDark
              ? AppColors.darkBgPrimary.withValues(alpha: 0.85)
              : AppColors.lightBgPrimary.withValues(alpha: 0.85),
          child: TabBar(
            controller: tabController,
            isScrollable: true,
            tabAlignment: TabAlignment.start,
            physics: const BouncingScrollPhysics(),
            indicatorSize: TabBarIndicatorSize.tab,
            labelPadding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 0,
            ),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            indicatorPadding: const EdgeInsets.symmetric(
              horizontal: 4,
              vertical: 6,
            ),
            indicator: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              gradient: const LinearGradient(
                colors: [Color(0xFF7C3AED), Color(0xFFA855F7)],
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFF7C3AED).withValues(alpha: 0.35),
                  blurRadius: 10,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            labelStyle: GoogleFonts.inter(
              fontSize: 13,
              fontWeight: FontWeight.w600,
            ),
            unselectedLabelStyle: GoogleFonts.inter(
              fontSize: 13,
              fontWeight: FontWeight.w400,
            ),
            labelColor: Colors.white,
            unselectedLabelColor: isDark
                ? AppColors.darkTextSecond
                : AppColors.lightTextSecond,
            tabs: categories.map((c) => Tab(text: c)).toList(),
          ),
        ),
      ),
    );
  }

  @override
  bool shouldRebuild(_CategoryBarDelegate old) =>
      old.isDark != isDark || old.categories != categories;
}

// ─────────────────────────────────────────────────────────────────────────────
// PRODUCT CARD
// ─────────────────────────────────────────────────────────────────────────────

class _ProductCard extends StatefulWidget {
  final CatalogItem item;
  final bool isDark;
  final VoidCallback onTap;

  const _ProductCard({
    required this.item,
    required this.isDark,
    required this.onTap,
  });

  @override
  State<_ProductCard> createState() => _ProductCardState();
}

class _ProductCardState extends State<_ProductCard>
    with SingleTickerProviderStateMixin {
  late final AnimationController _hoverCtrl;
  late final Animation<double> _scaleAnim;
  bool _wishlist = false;

  @override
  void initState() {
    super.initState();
    _hoverCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 180),
    );
    _scaleAnim = Tween<double>(
      begin: 1.0,
      end: 0.97,
    ).animate(CurvedAnimation(parent: _hoverCtrl, curve: Curves.easeOut));
  }

  @override
  void dispose() {
    _hoverCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final item = widget.item;
    final isDark = widget.isDark;
    final imageUrl = item.imageUrls.isNotEmpty ? item.imageUrls.first : null;
    final isOutOfStock = item.status == ListingStatus.outOfStock;
    final category = (item.metadata['category'] as String? ?? '').toUpperCase();

    return ScaleTransition(
      scale: _scaleAnim,
      child: GestureDetector(
        onTapDown: (_) => _hoverCtrl.forward(),
        onTapUp: (_) {
          _hoverCtrl.reverse();
          widget.onTap();
        },
        onTapCancel: () => _hoverCtrl.reverse(),
        child: Container(
          decoration: BoxDecoration(
            color: isDark ? AppColors.darkBgSurface : AppColors.lightBgSurface,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: isDark
                  ? Colors.white.withValues(alpha: 0.06)
                  : Colors.black.withValues(alpha: 0.05),
            ),
            boxShadow: [
              BoxShadow(
                color: isDark
                    ? Colors.black.withValues(alpha: 0.3)
                    : const Color(0xFF7C3AED).withValues(alpha: 0.06),
                blurRadius: 20,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ── Image ──────────────────────────────────────────────────
              Expanded(
                flex: 5,
                child: Stack(
                  children: [
                    // Image
                    ClipRRect(
                      borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(20),
                      ),
                      child: SizedBox.expand(
                        child: imageUrl != null && imageUrl.startsWith('http')
                            ? Image.network(
                                imageUrl,
                                fit: BoxFit.cover,
                                errorBuilder: (ctx, err, stack) =>
                                    _ImagePlaceholder(isDark: isDark),
                              )
                            : _ImagePlaceholder(isDark: isDark),
                      ),
                    ),

                    // Out of stock overlay
                    if (isOutOfStock)
                      Positioned.fill(
                        child: ClipRRect(
                          borderRadius: const BorderRadius.vertical(
                            top: Radius.circular(20),
                          ),
                          child: Container(
                            color: Colors.black.withValues(alpha: 0.5),
                            alignment: Alignment.center,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: Colors.black.withValues(alpha: 0.7),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                'OUT OF STOCK',
                                style: GoogleFonts.inter(
                                  color: Colors.white,
                                  fontSize: 9,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 0.8,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),

                    // Category pill
                    if (category.isNotEmpty)
                      Positioned(
                        top: 8,
                        left: 8,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 3,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.black.withValues(alpha: 0.55),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            category,
                            style: GoogleFonts.inter(
                              color: Colors.white,
                              fontSize: 8,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0.5,
                            ),
                          ),
                        ),
                      ),

                    // Wishlist button
                    Positioned(
                      top: 6,
                      right: 6,
                      child: GestureDetector(
                        onTap: () => setState(() => _wishlist = !_wishlist),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          width: 30,
                          height: 30,
                          decoration: BoxDecoration(
                            color: _wishlist
                                ? AppColors.lightAccentPink.withValues(
                                    alpha: 0.9,
                                  )
                                : (isDark
                                      ? Colors.black.withValues(alpha: 0.5)
                                      : Colors.white.withValues(alpha: 0.85)),
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.12),
                                blurRadius: 6,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Icon(
                            _wishlist
                                ? Icons.favorite_rounded
                                : Icons.favorite_border_rounded,
                            size: 14,
                            color: _wishlist
                                ? Colors.white
                                : AppColors.lightAccentPink,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // ── Info ───────────────────────────────────────────────────
              Expanded(
                flex: 3,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      // Rating
                      Row(
                        children: [
                          const Icon(
                            Icons.star_rounded,
                            color: Color(0xFFF59E0B),
                            size: 12,
                          ),
                          const SizedBox(width: 3),
                          Text(
                            '4.8',
                            style: GoogleFonts.inter(
                              fontSize: 10,
                              fontWeight: FontWeight.w700,
                              color: isDark
                                  ? AppColors.darkTextPrimary
                                  : AppColors.lightTextPrimary,
                            ),
                          ),
                          const SizedBox(width: 3),
                          Text(
                            '(142)',
                            style: GoogleFonts.inter(
                              fontSize: 9,
                              color: isDark
                                  ? AppColors.darkTextSecond
                                  : AppColors.lightTextSecond,
                            ),
                          ),
                        ],
                      ),

                      // Title
                      Text(
                        item.title,
                        style: GoogleFonts.inter(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: isDark
                              ? AppColors.darkTextPrimary
                              : AppColors.lightTextPrimary,
                          height: 1.3,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),

                      // Price row
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            '₹${item.basePrice.toStringAsFixed(0)}',
                            style: GoogleFonts.inter(
                              fontSize: 15,
                              fontWeight: FontWeight.w800,
                              color: isDark
                                  ? AppColors.darkAccentPurple
                                  : AppColors.lightAccentPurple,
                            ),
                          ),
                          // Add to cart mini button
                          Container(
                            width: 28,
                            height: 28,
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [Color(0xFF7C3AED), Color(0xFFA855F7)],
                              ),
                              borderRadius: BorderRadius.circular(8),
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(
                                    0xFF7C3AED,
                                  ).withValues(alpha: 0.3),
                                  blurRadius: 6,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.add_rounded,
                              color: Colors.white,
                              size: 16,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// SORT BOTTOM SHEET
// ─────────────────────────────────────────────────────────────────────────────

class _SortSheet extends StatelessWidget {
  final bool isDark;
  final String current;
  final void Function(String) onSelected;

  const _SortSheet({
    required this.isDark,
    required this.current,
    required this.onSelected,
  });

  static const _options = [
    ('popular', Icons.local_fire_department_rounded, 'Most Popular'),
    ('price_asc', Icons.arrow_upward_rounded, 'Price: Low to High'),
    ('price_desc', Icons.arrow_downward_rounded, 'Price: High to Low'),
    ('newest', Icons.fiber_new_rounded, 'Newest First'),
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: isDark ? AppColors.darkBgSurface : AppColors.lightBgSurface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
      ),
      padding: const EdgeInsets.fromLTRB(24, 12, 24, 32),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              width: 36,
              height: 4,
              decoration: BoxDecoration(
                color: isDark ? Colors.white24 : Colors.black12,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          const SizedBox(height: 20),
          Text(
            'Sort By',
            style: GoogleFonts.playfairDisplay(
              fontSize: 20,
              fontWeight: FontWeight.w700,
              color: isDark
                  ? AppColors.darkTextPrimary
                  : AppColors.lightTextPrimary,
            ),
          ),
          const SizedBox(height: 16),
          ..._options.map((opt) {
            final (value, icon, label) = opt;
            final selected = current == value;
            return GestureDetector(
              onTap: () => onSelected(value),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 150),
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 14,
                ),
                decoration: BoxDecoration(
                  color: selected
                      ? AppColors.primary.withValues(alpha: 0.1)
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: selected
                        ? AppColors.primary.withValues(alpha: 0.4)
                        : (isDark
                              ? Colors.white.withValues(alpha: 0.07)
                              : Colors.black.withValues(alpha: 0.06)),
                  ),
                ),
                child: Row(
                  children: [
                    Icon(
                      icon,
                      size: 18,
                      color: selected
                          ? AppColors.primary
                          : (isDark
                                ? AppColors.darkTextSecond
                                : AppColors.lightTextSecond),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      label,
                      style: GoogleFonts.inter(
                        fontSize: 14,
                        fontWeight: selected
                            ? FontWeight.w600
                            : FontWeight.w400,
                        color: selected
                            ? AppColors.primary
                            : (isDark
                                  ? AppColors.darkTextPrimary
                                  : AppColors.lightTextPrimary),
                      ),
                    ),
                    const Spacer(),
                    if (selected)
                      Container(
                        width: 18,
                        height: 18,
                        decoration: BoxDecoration(
                          color: AppColors.primary,
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.check_rounded,
                          size: 11,
                          color: Colors.white,
                        ),
                      ),
                  ],
                ),
              ),
            );
          }),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// SMALL WIDGETS
// ─────────────────────────────────────────────────────────────────────────────

class _GlassIcon extends StatelessWidget {
  final bool isDark;
  final IconData icon;
  final VoidCallback? onTap;

  const _GlassIcon({required this.isDark, required this.icon, this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 38,
        height: 38,
        decoration: BoxDecoration(
          color: isDark
              ? Colors.white.withValues(alpha: 0.07)
              : Colors.black.withValues(alpha: 0.04),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isDark
                ? Colors.white.withValues(alpha: 0.08)
                : Colors.black.withValues(alpha: 0.06),
          ),
        ),
        child: Icon(
          icon,
          size: 18,
          color: isDark
              ? AppColors.darkTextPrimary
              : AppColors.lightTextPrimary,
        ),
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool isDark;
  final VoidCallback onRemove;

  const _FilterChip({
    required this.label,
    required this.isDark,
    required this.onRemove,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: AppColors.primary.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.primary.withValues(alpha: 0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            label,
            style: GoogleFonts.inter(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: AppColors.primary,
            ),
          ),
          const SizedBox(width: 4),
          GestureDetector(
            onTap: onRemove,
            child: const Icon(
              Icons.close_rounded,
              size: 13,
              color: AppColors.primary,
            ),
          ),
        ],
      ),
    );
  }
}

class _ImagePlaceholder extends StatelessWidget {
  final bool isDark;

  const _ImagePlaceholder({required this.isDark});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: isDark
          ? Colors.white.withValues(alpha: 0.04)
          : Colors.black.withValues(alpha: 0.03),
      child: Icon(
        Icons.image_outlined,
        size: 36,
        color: isDark ? AppColors.darkTextSecond : AppColors.lightTextSecond,
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  final bool isDark;

  const _EmptyState({required this.isDark});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: AppColors.primary.withValues(alpha: 0.08),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.search_off_rounded,
              size: 36,
              color: isDark
                  ? AppColors.darkAccentPurple
                  : AppColors.lightAccentPurple,
            ),
          ),
          const SizedBox(height: 20),
          Text(
            'Nothing found',
            style: GoogleFonts.playfairDisplay(
              fontSize: 22,
              fontWeight: FontWeight.w700,
              color: isDark
                  ? AppColors.darkTextPrimary
                  : AppColors.lightTextPrimary,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Try a different category or search term',
            style: GoogleFonts.inter(
              fontSize: 13,
              color: isDark
                  ? AppColors.darkTextSecond
                  : AppColors.lightTextSecond,
            ),
          ),
        ],
      ),
    );
  }
}
